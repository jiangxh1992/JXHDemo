//
//  EditTypeViewController.h
//  slyy_department_edition
//
//  Created by 919575700@qq.com on 12/18/15.
//  Copyright © 2015 eeesysmini2. All rights reserved.
//  编辑就诊类型

@interface EditTypeViewController : ESListViewController

@end
